namespace Domain.Enums;

public enum CourseStatus
{
    Draft = 0,
    Published = 1
}
